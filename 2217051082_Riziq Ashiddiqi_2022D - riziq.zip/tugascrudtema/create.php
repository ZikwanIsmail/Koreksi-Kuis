<?php include 'mainindex.php' ; ?>
<!DOCTYPE html>
<html>
    <head>
        <title>
            Tambah anggota
        </title>
    </head>
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet">
<body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

    <div class="navbar navbar-light justify-content-center fs-3 mb-5" style="background-color: orange;">
        Tugas CRUD <br>
    </div>

    <div class="container">
        <div class="text-center mb-4">
            <h3>Tambahkan anggota</h3>
        </div>
    </div>
    <div class="container d-flex justify-content-center">
        <form method="post" action="create.php" style="width:50vw; min-width: 300px;">
            <label class="form-label">Nama:</label>
            <input type="text" class="form-control" name="nama" placeholder="Nama" required>
            <br>
            <label class="form-label">Tugas:</label>
            <input type="text" class="form-control" name="tugas" placeholder="Tugas" required>
            <br>
            <label class="form-label">Tanggal Gabung:</label>
            <input type="date" class="form-control" name="tanggalgabung" placeholder="Tanggal Gabung" required>
            <br>
            <button type="submit" class="btn btn-success mb-3">Tambah anggota</button>
            <br>
            <a href="index.php" class="container btn btn-sm btn-dark justify-content-center mb-3">Kembali ke daftar anggota</a>
        </form>
    </div>
    <?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
        $name = $_POST['nama'];
        $task = $_POST['tugas'];
        $joindate = $_POST['tanggalgabung'];

        $stmt = $conn->prepare("INSERT INTO anggota (nama, tugas, tanggalgabung) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $task, $joindate);
        if ($stmt->execute()){
            echo "Anggota baru ditambahkan.";
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    }
    ?>
</body>
</html>