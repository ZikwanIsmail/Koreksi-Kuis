<?php include 'mainindex.php' ; ?>
<!DOCTYPE html>
<html>
    <head>
        <title>
            Tugas Kuis CRUD
        </title>
    </head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet">
<body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

    <div class="navbar navbar-light justify-content-center fs-3 mb-5" style="background-color: orange;">
        Tugas CRUD <br>
    </div>

    <div class="container">
        <div class="text-center mb-4">
            <h3>Daftar anggota perusahaan</h3>
        </div>
    </div>

    <div class="container">
        <a href="create.php" class="btn btn-dark mb-3">Tambah anggota baru</a>
        <table class="table table-hover text-center">
            <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Tugas</th>
                <th>Tanggal Gabung</th>
                <th>Ubah...</th>
            </tr>
            </thead>
            <tbody>
                <?php
                $result = $conn->query("SELECT * FROM anggota");
                while($row = $result->fetch_assoc()){
                    echo "<tr>
                    <td>".$row['id']."</td>
                    <td>".$row['nama']."</td>
                    <td>".$row['tugas']."</td>
                    <td>".$row['tanggalgabung']."</td>
                    <td>
                        <a href='update.php?id=".$row['id']."' class='btn btn-sm btn-dark'>Perbarui</a> 
                        <a href='delete.php?id=".$row['id']."' class='btn btn-sm btn-danger'>Hapus</a> 
                    </td>
                    </tr>";
                }
                ?>
            </tbody>
    </div>
    
</body>
</html>