url admin = http://localhost/antrianrs/admin/

username = admin
password = admin

