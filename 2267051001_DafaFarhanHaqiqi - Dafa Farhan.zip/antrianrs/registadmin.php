<?php
include 'connection.php';

// Pengguna dan kata sandi baru yang ingin Anda tambahkan
$username = "admin";
$password = "admin";
$id_level = 5;
$supervisor = "junet";  // Mengatur nilai default untuk kolom supervisor

// Hash kata sandi menggunakan bcrypt
$hashedPassword = password_hash($password, PASSWORD_BCRYPT);


dd($hashedPassword);
// Menyiapkan pernyataan SQL dengan parameter
$sql = "INSERT INTO user (username, id_level, supervisor, password) VALUES (?, ?, ?, ?)";

if ($stmt = $conn->prepare($sql)) {
    
    // Mengikat parameter ke pernyataan yang dipersiapkan
    $stmt->bind_param("siss", $username, $id_level, $supervisor, $hashedPassword);
    // Menjalankan  yang dipersiapkpernyataanan
    if ($stmt->execute()) {
        
        echo "Registration successful!";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Menutup pernyataan
    $stmt->close();
} else {
    echo "Error: " . $conn->error;
}

// Menutup koneksi
$conn->close();
?>
