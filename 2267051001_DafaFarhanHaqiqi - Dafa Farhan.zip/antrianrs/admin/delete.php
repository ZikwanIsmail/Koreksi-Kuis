<?php

    include '../connection.php';
   
if(isset($_GET['id'])) {
   
    $id = mysqli_real_escape_string($conn, $_GET['id']);

    $sql = "DELETE FROM dokter WHERE id = '$id'";

    if ($conn->query($sql) === TRUE) {
        header("Location: http://localhost/antrianrs/admin/");
        exit; 
    } else {
        echo "Error deleting record: " . $conn->error;
    }

    $conn->close();
} else {
    echo "No parameter 'id' provided.";
}
if(isset($_GET['no'])) {
   
    // Sanitize the input to prevent SQL injection
    $no = mysqli_real_escape_string($conn, $_GET['no']);

    // SQL query to delete row from 'antrian' table where 'no' matches the value from GET request
    $sql = "DELETE FROM antrian WHERE no = '$no'";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        // If deletion is successful, redirect back
        header("Location: http://localhost/antrianrs/admin/");
        exit; // Ensure to exit after the redirect
    } else {
        // If an error occurred, display error message
        echo "Error deleting record: " . $conn->error;
    }

    // Close the database connection
    $conn->close();
} else {
    // If 'no' parameter is not set, handle the case here
    echo "No parameter 'no' provided.";
}
?>