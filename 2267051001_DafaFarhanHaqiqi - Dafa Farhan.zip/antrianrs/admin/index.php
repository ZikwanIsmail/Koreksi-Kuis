<?php
include '../connection.php'; 

session_start();



if(isset($_POST['nama']) && isset($_POST['spesialisasi']) && isset($_POST['jadwal'])) {
  $nama = mysqli_real_escape_string($conn, $_POST['nama']);
  $spesialisasi = mysqli_real_escape_string($conn, $_POST['spesialisasi']);
  $jadwal = mysqli_real_escape_string($conn, $_POST['jadwal']);
  if(isset($_POST['adddokter'])){
    // SQL query to insert data into 'dokter' table
    $sql = "INSERT INTO dokter (nama, spesialisasi, jadwal) VALUES ('$nama', '$spesialisasi', '$jadwal')";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
      echo "<script>alert('New record created successfully');</script>";
      // Then redirect after alert is clicked
      echo "<script>window.location.href = 'http://localhost/antrianrs/admin/';</script>";
      exit; // Ensure to exit after the redirect

    } else {
      echo "<script>alert('Error Add Data!');</script>";
    }
  }else if(isset($_POST['editdokter'])){
    $id = $_POST['id'];

    // SQL query to update data in 'dokter' table
    $sql = "UPDATE dokter SET nama='$nama', spesialisasi='$spesialisasi', jadwal='$jadwal' WHERE id='$id'";
    // Execute the query
    
    if ($conn->query($sql) === TRUE) {
      echo "<script>alert('Record updated successfully');</script>";
      echo "<script>window.location.href = 'http://localhost/antrianrs/admin/';</script>";
      exit; // Ensure to exit after the redirect

    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
  }

  // Close the database connection
  $conn->close();
}

if(isset($_POST['submit'])){
    // Get username and password from the form
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Retrieve the hashed password from the database based on the username
    $sql = "SELECT id, password FROM users WHERE username='$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // User found
        $row = $result->fetch_assoc();
        $hashedPassword = $row['password'];

        // Verify the password
        if (password_verify($password, $hashedPassword)) {
        // Set session variables
            echo "<script>alert('Login Success !');</script>";
            $_SESSION['username'] = $username;

        
        } else {
        echo "<script>alert('Login Failed!');</script>";
            
        
        }
    } else {
        // User not found
        echo "<script>alert('Login Failed!');</script>";
    }
}

?>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<?php if(isset($_SESSION['username'])): ?>
  <?php            
    $sql = "SELECT * FROM antrian";
    $result = $conn->query($sql);
    $sql = "SELECT * FROM dokter";
    $dokter = $conn->query($sql);
  ?>
   <body>

    <!-- DASHBOARD -->
    <nav class="bg-gray-100 border-b-2 border-gray-400">
  <div class="max-w-6xl mx-auto px-4">
    <div class="flex justify-between">

      <div class="flex space-x-4">
        <!-- logo -->
        <div>
          <a href="#" class="flex items-center py-5 px-2 text-gray-700 hover:text-gray-900">
           <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAZAAAABkCAMAAACfFZZFAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAABaUExURUdwTP///0qcLg0fbP////////////////////////PEA/j6+likPkebKuns7/L47Rgpcj1LiXOzXc3fzSY3e3mDrezvzbrA1VZimJTFg7XXqvjZXZqhwaTOlk06+a4AAAAKdFJOUwD///+p2SWziU4ftVUrAAAOxklEQVR42uxciXbbOAwsraZJQ4k6KIqSLP3/by7A+5LiXnG8z+jbbiPZtI3hABiAzrdv/wf78fP15eX1+89vT/sS9kaJtpe3pzO+gH0HKNppahUkP57+uLf9JGS6voNdr+0TkS+QP17I9G7tSsgzat07gZDW4fE+PRlydwsJ8t6SZ6V174hFyTWIWC9Pj9w9pUcR6/vTI18LkGdKvz8g0xOQJyBPuxWQ7z9/POverwQIIfTl5dllvGPV+xYDQnWf8eUJyZ3geCExINssJENIXp+R6w5wAB1oDIioqmoU/Nn3vUf2AHawTdAMkKrqBHsi8tn2BuyQfdWXAAGWSPJU7Z9qr0AP9P4BINUIYeuZ2T8VDzpXJ4BUMyWvTz99ZrxSeBwDUklCHzGLvL0+ogEewhLhCBBByNvPhzPk/kPaZtx+zJD5ET/WiwKEPpgRF7DOABGP98kMIKJ7LJsREam93iWAQCHsAaFD/Vg2GECqhzIoaJkgrC/mEEK45Q4nU31pHsoeExBBqRgZ4V0pZBGX7oFH6+Wx7DEBAYLIDhOELAHCeas/UM8Iqx8MkEsRkK4Xm+RcSinmPnFG130BghAGQamTutBKc8h+qSGidVXPIYNc/gcM6TdGXQ1GmRQBBDPgtCFGvRCbwP/Gz8cDkFDUAI8jU1KG7M2lZmSTjLQPh0eBIb2eJQRGubsr1D1MprPBjPafGqv0rmAmnWOzKm8u7pAad/W+a/hXvP8+vPBJPDh81YwhMytKME2S0dyU430A6bicR0weJpsrRNicVFl8WRYAhK2LsmHweWTZ9yV0Rb3Dhc/Ho4a3Vd/GkDIehMrO6ixl/X0A6SmEUM6Z0+iqxc5kOlNP3vy0208P2X6KAIELvPlEAlgWHGa3hCE9O5Dzuo50gMz3AWQj5isgPsKqOVQREBr8zQwknwJIM5wQwLDguNyIAMG65cBU1L43Qzie4b1eW9c00UmP2m+H6MO9mQFGdK3/NSD1vmonNys5L7dvZ0jvqysmN6h8A8Jg0HI5pLsLICPTR0bb6EW7TnBKWo9IbgAJ3f8xIFDYkba+CZDbGbL5CDUaPcIiiugUw4+qrC74O/qhu+X2R4911VSb7oIR3+Z0Cglhw78FZEBvDBaQ6a8wxEcsEfVL/bVuloyp5l0MyOeIRXuYoSVzlu5lnEkym8jyjwGhISB/hyEupbMxHLrZQitS6mWGjP0ManHuiwDZu3M/lgHs8H7wZPWz6N0FQSwgeaenQ/KexK2rcvy/A6SpF9bul7/LEA9IV+UUkbgPjRWrrF5YTQnyfh5TZ29ecYL6t08TZsWxUqlA3VWtAIhDktpHjxEgk9Mh0Sts9CxutdMNDMH+dyk/lC8npW5dN0eA1PEKESDJ4iEgNmeTsIrpmZmcICA+fGWAjFtQAcBNHnZcqjmt35jRmtIMkHrsg9jn4lmSPnwG7zUrW7Pb7fC2y+LWIUkmjCKngNTDyic28XWoI1/ucBUuu0pWO7Aeln3dF7/RBzDY4GDwSdpB/WhkIEinKVghYAjcM4s3BYaMfguLIG5YOwUkVzBUjl4s0LyQ1reN2+kWP18k66mSAt7f1cQsVizuOjyveADJR4DUg5eUzMuImru3zrQPF8b25rLY65N1Ozx9bRoebiPtchasGzOkXlt7y4S7pMoKNiXf+rxteAxIUeFbRIp4mN75gfJh6Xoqikrj7auuwkuV8XZUb30QshrlYNqyVr1XbhAZ2uCqLp0XcPxlDVSnkjiNBuSSAlKrCy2YXqEJGFJP4UtqpRTrEBH7ACJ9dxsgBwpfVlEBkFp/DEhuZsDRXq9ajm9xrV1FzbhYGCpAPkjqym8c573DSj0ik7uKgKltjYBg7xJ7ZbuCcQ8YsnNs7RAK/+M4HFOPXNwKuv+sAVFsmhb1kvA+qO6yxcIw8isO3IP0ewLIkcI3od7vGhyxsOjUyM2ASE/Eto0jYgyKSu5pN+t6JYsFxJsDRHWH2dDYMIUbFrcrOJ8sNri3es/DNXAtRB+92fGxsLRlCPzRSR3/oYthyzb1w+oZMphXUVcmUyonvSxRDB9u5nEEiAgeO/ezzweqfu6jRIByIhD/UZQUUeufSmELLbRORz/JGRoN31caWdXW84b4tdQIw3YNjWpA0DeBdEBE8PG4h7lvFesNvpDowfhY/MkAkuiQ3cp3Zbb80oDsAV0bBGvIu73FrU4h5Y5ngHQ8bgpXrmJSJBAxXzwIPARE3+14mMe7kLRxGh8RKhpVcl04wQJHeiJgFJpM6yQzAKThsTBoLkwh0UyOIKY5shhAhkA4wKI4E4sAMWUvorU2oXhEpDRD8GHuXmMfmc5Duu2kt3gESB/2u6pM0Wyp3NxKgGzp0baUtHNJnDNxNOT1kUKn3OUEkNoHD88GjPKTSRCujsL6iiRiUvu/yBDAMAQasGsdQ/BhwTr2p2xiOPMyIvMxIFu+iYO+cCU2bXY7dyWG2PK5szGKj0mYzNol+q2yuVwAx4hcXPs94z/XPq5j3Y0UUUVsGMnUrCvIK27fg9eLDLns+15ngDQuZAUzZr14aabuFHPOkTIg3sHRKCnc553vE/azywssAMQ1B1jCNrdSwfGqqUhlX567R25rLCCq/nFGnN8T4a0vKTYkTY4lilgulJVzSGwrCRiiEheomObjUyddL2Rex4KHDgBhyVlbXILFHTD0Xg85WrLgAEXIEAdmuth4AohJJawEyVg644BVVnhwTldZGJmSjlajSYO+Ji2HstXPADGaxXTiGMrKDLG7AUrbYUH4A4aoUpvyHZjRfHguqxvnLQGFzgeAOIEfLiJjKdJvnGW8CwGRKSCi+pghPpVsOSRQIq8lQDBzmj+27G3DVOG76eAzI99bpvxmAWHZxufNMUOGZeVG/EUMMaIRp9KweHN2LsuBEmEiDwApuiza+b0sSsObABk/AARHAvihtqwGlmHFeTZTr2mSFTwgTb27joqZAy/JGkrE8COG1MvkPnuLg7SAIU1ws9VCPWLIOBvrkyjtfPsbgDB3eKiQls4A2W5kiKvpmEg1O83c/MuAqGy78zboZt0EiGXIwA0UQIKhHljEELO4+cTtkjJE2BPxWxYSTNn6ASCizJCeJh0Z/lcZotLFNOWQQB7jNwFyFLK8+EO/4fswwpDFCeeYIapbxSAg1VayhAxR2aVxi6tLIUMESZ0TC+sjQEo5xAk8GYpxJjccQG1/kkO6/FCr6gKrowxy7qJNkc6JyoAUknpeCdeDaahgUs8qsrXMEFOlNSUdEkxSzOK8jhnifMzGZP+dAxI6P3vS5rc4E2ZSuP0FhnRQdIgQkPd3/IWkUcGVJ5EDQPKyV18KZ0ewk7UqSaFSUCxFHaJaL3Uk6j1DosVVA0zllQAQJ6+pSE6n2ZD/gQ4JgJx9GJuzQb384xyiU9sWA6LPZAUF15bUp4chK5MWFy0MdzX6SBRgLgxbfHaJIUqhNBHtPEMGxqJhpW7MhAzxfSRWSs/0qMrysW7rqrQnNrq7bqbkdMtvMwQlOpP+QKkFRMUtD4m8FRDM6mudt06WZMDLLCBRgNNuLuaQuHOChPEMGaK+o23MRGWvPwXE3CQkmKSKw15WSi0/kZJVDsj8pzoE6AHhr6e2keUB0XHLdLg6dmPIypqLmiDZ6RCgggEk5JNB4gaGDJEOqWm2zHJ06oRQ/BYCWiBEICAdtd+3qFPf9W4igcP5NGT5QfFvMgTeJtc9Zt5lgOCvZzI7A6C8Lamb9vtwCVuv6Cx1uw7L21bnkHDh3Y//EoaodXjk8oAhuAuCZXQ8PJ0Y5l9CPgIkGGyxaAQlw+4g3XAyH4iS38shEA412YSNkTEgVGxM7QRBMql+ODHcg+m4Fg/cuNbFMlQR6PJFje64kdb1YuZWASC7I9Zu57561VaRojbMW0g4vJrcrOS2s71qQH44wi0PzfVhkY7FQ0jqA+P4OwwB9IU7+c7nLgNkxnkMVCAsP/x0PsKlqxq17sx5SvWyJpzADmqy2+puLzYl2VLbeS86Mih7lafZvuyLHsmbwTDEO+xmtXwNe1lKpMBdVtAh5vsW5Ni3h4CUxyimNjjkHT7313OIcNWcqrVA20iaAIKfQ8ikAX8OSK0m6YS2WpS7Qw767egjCl6pq5hG2aRP1g6XiCEaRk2yhfqn00UREV4wPOSAr0mDIylJL2uUB98P6c9PnZQ4YrN4d/QdB/TxrzNEBnqnF5ypXyKQAAIw0tLpwLNzWYObOtBp8dLBn9Rhq+9l+QM85iowhNI1XkpN4Ce36IBJpaUtMITSNj0GZLr8ebe3NA2x0+uzg3LpYCs4hND/197Z8CYIA2E4OIySgpaUj4n6///megVKv4Qts7Pn7jITsKxL9uQKvbv3EE6NnPFP//k9pLfC/B9Qn+p5yDjv3UtIiK6znlhL+cV9yWvf5Wlnhl5VQeJlgF8bLku0F6BCiZu62CiUK41sE2i3FCgovxNT9Z2cDa4q52vVKAxf9HY+lKDqXRz1Zl2Wls7YLhUoBJEj5k7yYT5kxUNufnDRA9IGFqydmwzaPNexDWNIBxereUijM+dZVFSVLamqqulnmdwYDudDQBWtajtOwqrN0lWMzXLI7cQWpOH6m1vZC3W/Ama7KbjNNEvN58Na86vnQfdv8sCS9RAIjydR96K9GzifoVNPR5Ee1LW5pdYBIK0fUI8P5J92cmg91Zb32AubUbFDCUR5SI4KiPSHfsNDPpmfLMTkIblRHLIqE/8zrdSq9ZZcwgfStixmTw3MHhKHnnwQttUINpBMbXqr3Tt4CJq7iJ2tdYKLZpwwBhDGRLIe8qIFDAI1RrbW8RA2RO3J9B192xOANKhMBWpAKlE3nHMHyFBitgnICZmxUb/ExrPM9pAzahuBYLfrSvMZfG1if9VIOd/+5LHNBnI4Ijf8LxGxor3Uf5+AkBEQAkJGQAgIGQEhIGTxrcgICAEhIyBo7EhAEgZyJiAvt0OWGd1HGb3/9tW2Nzr2Qn6HLJ1tSEdvv03jKau7zsJoej90CkT2Y+PPTPKgO0gSq9Zxr6QOB1qv0mFSFMWbeMcXnus/AEOspVkAAAAASUVORK5CYII=" 
           alt="" class="h-12 object-contain"/>
          </a>
        </div>

        <div class="hidden md:flex items-center space-x-1">
          <button onclick="show('dokter')" class="py-5 flex px-3 text-gray-700 hover:text-gray-900 hover:italic hover:underline rounded-lg bg-gray-200 h-10 items-center">Master Dokter</button>
          <button onclick="show('antrian')" class="py-5 flex px-3 text-gray-700 hover:text-gray-900 hover:italic hover:underline rounded-lg bg-gray-200 h-10 items-center" >Master Antrian</button>
        </div>
      
       
      </div>

      <!-- secondary nav -->
      <div class="hidden md:flex items-center space-x-1">
        <a href="logout.php" class="py-5 px-3 hover:scale-110 hover:italic hover:underline">Logout</a>
        <span class="py-2 px-3 bg-yellow-400 hover:bg-yellow-300 text-yellow-900 hover:text-yellow-800 rounded transition duration-300"><?= $_SESSION['username'];?></span>
      </div>

      <!-- mobile button goes here -->
      <div class="md:hidden flex items-center">
        <button class="mobile-menu-button">
          <svg class="w-6 h-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>

    </div>
  </div>

  <!-- mobile menu -->
  <div class="mobile-menu hidden md:hidden">
    <button onclick="show('dokter')" class="block py-2 px-4 text-sm hover:bg-gray-200 " >Master Dokter</button>
    <button onclick="show('antrian')" class="block py-2 px-4 text-sm hover:bg-gray-200">Master Antrian</button>
  </div>
</nav>

    
   <section id="antrian" class="container mx-auto px-4 sm:px-8 ">
  <div class="py-8">
    <div>
      <h2 class="text-2xl font-semibold leading-tight">Antrian</h2>
    </div>
    <div class="-mx-4 sm:-mx-8 px-4 sm:px-8 py-4 overflow-x-auto">
      <div
        class="inline-block min-w-full shadow-md rounded-lg overflow-hidden"
      >
        <table class="min-w-full leading-normal">
          <thead>
            <tr>
              <th
                  class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider"
                >
                No
              </th>
              <th
                class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider"
              >
                Nama
              </th>
              <th
                class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider"
              >
                Nik
              </th>
              <th
                class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider"
              >
                Nomor
              </th>
              <th
                class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider"
              >
                Dokter
              </th>
              <th
                class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider"
              >
                Jadwal
              </th>
              <th
                class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider"
              >
                Spesialisasi
              </th>
              <th
                class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100"
              ></th>
            </tr>
          </thead>
          <tbody>
          <?php $index = 1; foreach ($result as $row): ?>
            <tr>
               <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                    <?php echo $index++; ?>
                </td>
                <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                    <?php echo $row['nama']; ?>
                </td>
                <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                    <?php echo $row['nik']; ?>
                </td>
                <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                    <?php echo $row['no']; ?>
                </td>
                <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                    <?php echo $row['dokter']; ?>
                </td>
                <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                    <?php echo $row['jadwal']; ?>
                </td>
                <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                    <?php echo $row['spesialisasi']; ?>
                </td>
                <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                    <a href="delete.php?no=<?=$row['no']?>" onclick="confirmDelete(<?php echo $row['id']; ?>)" class="focus:outline-none text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-900">DELETE</a>
                </td>
            </tr>
        <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</section>






    
<section id="dokter" class="container mx-auto px-4 sm:px-8 hidden">
  <div class="py-8">
    <div>
      <h2 class="text-2xl font-semibold leading-tight">Dokter</h2>
      <button onclick="showModal('modal')"  class="mt-2 focus:outline-none text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:blue-green-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-900">TAMBAH</button>
      <div id="modal" class="hidden rounded-lg  bg-white absolute z-10 p-20 border-2" style="left: 50%;top:50%;
    transform: translate(-50%, -50%);">
      <button onclick="hideModal('modal')" class="absolute top-0 right-0 p-4 bg-black text-white rounded-lg m-2">X</button>
      <form action="/antrianrs/admin/" method="post">
          <div class="mb-5">
            <label for="nama" class="block mb-2 font-bold text-gray-600">Nama Dokter</label>
            <input type="text" id="nama" name="nama" placeholder="Nama Dokter" class="border border-gray-300 shadow p-3 w-full rounded mb-">
          </div>

          <div class="mb-5">
            <label for="spesialisasi" class="block mb-2 font-bold text-gray-600">Spesialisasi Dokter</label>
            <input type="text" id="spesialisasi" name="spesialisasi" placeholder="Spesialisasi Dokter" class="border border-gray-300 shadow p-3 w-full rounded mb-">
          </div>

          <div class="mb-5">
            <label for="jadwal" class="block mb-2 font-bold text-gray-600">Jadwal Dokter</label>
            <input type="text" id="jadwal" name="jadwal" placeholder="Jadwal Dokter" class="border border-gray-300 shadow p-3 w-full rounded mb-">
          </div>

          <button class="block w-full bg-blue-500 text-white font-bold p-4 rounded-lg" type="submit" name="adddokter">Tambah Dokter</button>
        </form>
  </div>
    </div>
    <div class="-mx-4 sm:-mx-8 px-4 sm:px-8 py-4 overflow-x-auto">
      <div
        class="inline-block min-w-full shadow-md rounded-lg overflow-hidden"
      >
        <table class="min-w-full leading-normal">
          <thead>
            <tr>
              <th
                  class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider"
                >
                No
              </th>
              <th
                class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider"
              >
                Nama
              </th>
              <th
                class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider"
              >
                Spesialisasi
              </th>
              <th
                class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider"
              >
                Jadwal
              </th>
             
              <th
                class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100"
              ></th>
            </tr>
          </thead>
          <tbody>
          <?php $index = 1; foreach ($dokter as $row): ?>
            <tr>
               <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                    <?php echo $index++; ?>
                </td>
                <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                    <?php echo $row['nama']; ?>
                </td>
                <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                    <?php echo $row['spesialisasi']; ?>
                </td>
                <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                    <?php echo $row['jadwal']; ?>
                </td>
                <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                    <a href="delete.php?id=<?=$row['id']?>" onclick="confirmDelete(<?php echo $row['id']; ?>)" class="focus:outline-none text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-900">DELETE</a>
                    <button onclick="showModal('modal<?=$row['id']?>');" class="focus:outline-none text-white bg-green-700 hover:bg-green-800 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-900">EDIT</button>


                    <div id="modal<?=$row['id']?>" class="hidden rounded-lg  bg-white absolute z-10 p-20 border-2" style="left: 50%;top:50%;
                      transform: translate(-50%, -50%);">
                        <button onclick="hideModal('modal<?=$row['id']?>')" class="absolute top-0 right-0 p-4 bg-black text-white rounded-lg m-2">X</button>
                        <form action="/antrianrs/admin/" method="post">
                        <input type="hidden" name="id" value="<?=$row['id']?>" >

                            <div class="mb-5">
                              <label for="nama" class="block mb-2 font-bold text-gray-600">Nama Dokter</label>
                              <input type="text" value="<?=$row['nama']?>" id="nama" name="nama" placeholder="Nama Dokter" class="border border-gray-300 shadow p-3 w-full rounded mb-">
                            </div>

                            <div class="mb-5">
                              <label for="spesialisasi" class="block mb-2 font-bold text-gray-600">Spesialisasi Dokter</label>
                              <input type="text" id="spesialisasi" value="<?=$row['spesialisasi']?>" name="spesialisasi" placeholder="Spesialisasi Dokter" class="border border-gray-300 shadow p-3 w-full rounded mb-">
                            </div>

                            <div class="mb-5">
                              <label for="jadwal" class="block mb-2 font-bold text-gray-600">Jadwal Dokter</label>
                              <input type="text" id="jadwal" name="jadwal" value="<?=$row['jadwal']?>" placeholder="Jadwal Dokter" class="border border-gray-300 shadow p-3 w-full rounded mb-">
                            </div>

                            <button class="block w-full bg-blue-500 text-white font-bold p-4 rounded-lg" type="submit" name="editdokter">Simpan</button>
                          </form>
                    </div>


                </td>
            </tr>
        <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</section>


</div>
<script>
    function showModal(target){
      document.getElementById(target).style.display = 'flex';
    }
    function hideModal(target){
      document.getElementById(target).style.display = 'none';
    }
 
  function show(target){
    if(target=='dokter'){
      document.getElementById('dokter').style.display = 'block';
      document.getElementById('antrian').style.display = 'none';

    }else{
      document.getElementById('dokter').style.display = 'none';
      document.getElementById('antrian').style.display = 'block';
    }
  }
</script>
   </body>
    
<?php else: ?>
 <body class="antialiased bg-no-repeat bg-center bg-cover backdrop-blur-sm bg-[url('https://mysiloam-api.siloamhospitals.com/public-asset/website-cms/website-cms-16273593324767245.jpg')] text-gray-900 font-sans">
    <div class="flex items-center h-screen w-full">
      <div class="w-full bg-white rounded shadow-lg p-8 m-4 md:max-w-sm md:mx-auto">
      <span class="block w-full text-xl uppercase font-bold mb-4">Login</span>      
        <form class="mb-4" action="/antrianrs/admin/" method="post">
          <div class="mb-4 md:w-full">
            <label for="email" class="block text-xs mb-1">Username</label>
            <input class="w-full border rounded p-2 outline-none focus:shadow-outline" type="text" name="username" id="username" placeholder="Username">
          </div>
          <div class="mb-6 md:w-full">
            <label for="password" class="block text-xs mb-1">Password</label>
            <input class="w-full border rounded p-2 outline-none focus:shadow-outline" type="password" name="password" id="password" placeholder="Password">
          </div>
          <button class="bg-green-500 hover:bg-green-700 text-white uppercase text-sm font-semibold px-4 py-2 rounded" type="submit" name="submit">Login</button>
        </form>
    </div>
  </div>
</body>
<?php endif; ?>


</html>