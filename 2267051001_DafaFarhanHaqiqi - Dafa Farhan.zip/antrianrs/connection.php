<?php
// Konfigurasi database
$servername = "localhost"; 
$username = "root"; 
$password = "123";
$database = "antrianrs"; 

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $database);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

function dd($param){
    var_dump($param);
}
?>
