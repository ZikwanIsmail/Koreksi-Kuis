<?php include("config.php"); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Sederhana</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Daftar Paket Perjalanan</h2>
        <a href="create.php" class="btn btn-success">Tambah Paket Baru</a>
        <table>
            <tr>
                <th>Nama Paket</th>
                <th>Harga</th>
                <th>Durasi</th>
                <th>Fitur</th>
                <th>Aksi</th>
            </tr>
            <?php
            $stmt = $conn->prepare("SELECT * FROM addpackages");
            $stmt->execute();
            $packages = $stmt->fetchAll();
            foreach ($packages as $package) {
                echo "<tr>";
                echo "<td>".$package['package_name']."</td>";
                echo "<td>".$package['package_price']."</td>";
                echo "<td>".$package['package_duration']."</td>";
                echo "<td>".$package['package_features']."</td>";
                echo "<td><a href='read.php?id=".$package['id']."' class='btn btn-info'>Lihat</a> <a href='update.php?id=".$package['id']."' class='btn btn-warning'>Edit</a> <a href='delete.php?id=".$package['id']."' class='btn btn-danger'>Hapus</a></td>";
                echo "</tr>";
            }
            ?>
        </table>
    </div>
</body>
</html>
