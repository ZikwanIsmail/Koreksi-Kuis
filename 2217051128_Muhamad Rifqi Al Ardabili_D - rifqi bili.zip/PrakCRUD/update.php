<?php include("config.php"); ?>

<?php
$id = $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM addpackages WHERE id = :id");
$stmt->bindParam(':id', $id);
$stmt->execute();
$package = $stmt->fetch();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $duration = $_POST['duration'];
    $features = $_POST['features'];

    $stmt = $conn->prepare("UPDATE addpackages SET package_name = :name, package_price = :price, package_duration = :duration, package_features = :features WHERE id = :id");
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':price', $price);
    $stmt->bindParam(':duration', $duration);
    $stmt->bindParam(':features', $features);
    $stmt->bindParam(':id', $id);

    if ($stmt->execute()) {
        header("Location: index.php");
    } else {
        echo "Error: " . $stmt->errorInfo();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Paket</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Update Paket</h2>
        <form method="POST" action="">
            <label for="name">Nama Paket:</label>
            <input type="text" id="name" name="name" value="<?php echo $package['package_name']; ?>" required>
            <br>
            <label for="price">Harga:</label>
            <input type="text" id="price" name="price" value="<?php echo $package['package_price']; ?>" required>
            <br>
            <label for="duration">Durasi:</label>
            <input type="text" id="duration" name="duration" value="<?php echo $package['package_duration']; ?>" required>
            <br>
            <label for="features">Fitur:</label>
            <input type="text" id="features" name="features" value="<?php echo $package['package_features']; ?>" required>
            <br>
            <input type="submit" value="Update">
        </form>
    </div>
</body>
</html>
