<?php include("config.php"); ?>

<?php
$id = $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM addpackages WHERE id = :id");
$stmt->bindParam(':id', $id);
$stmt->execute();
$package = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lihat Paket</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h2>Detail Paket</h2>
    <p>Nama Paket: <?php echo $package['package_name']; ?></p>
    <p>Harga: <?php echo $package['package_price']; ?></p>
    <p>Durasi: <?php echo $package['package_duration']; ?></p>
    <p>Fitur: <?php echo $package['package_features']; ?></p>
    <a href="index.php">Kembali</a>
</body>
</html>
