<?php include("config.php"); ?>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $duration = $_POST['duration'];
    $features = $_POST['features'];

    $stmt = $conn->prepare("INSERT INTO addpackages (package_name, package_price, package_duration, package_features) VALUES (:name, :price, :duration, :features)");
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':price', $price);
    $stmt->bindParam(':duration', $duration);
    $stmt->bindParam(':features', $features);

    if ($stmt->execute()) {
        header("Location: index.php");
    } else {
        echo "Error: " . $stmt->errorInfo();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Paket Baru</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Tambah Paket Baru</h2>
        <form method="POST" action="">
            <label for="name">Nama Paket:</label>
            <input type="text" id="name" name="name" required>
            <br>
            <label for="price">Harga:</label>
            <input type="text" id="price" name="price" required>
            <br>
            <label for="duration">Durasi:</label>
            <input type="text" id="duration" name="duration" required>
            <br>
            <label for="features">Fitur:</label>
            <input type="text" id="features" name="features" required>
            <br>
            <input type="submit" value="Simpan">
        </form>
    </div>
</body>
</html>
