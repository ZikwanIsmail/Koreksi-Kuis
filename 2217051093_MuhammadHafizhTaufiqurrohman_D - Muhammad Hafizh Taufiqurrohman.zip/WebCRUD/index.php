<?php include 'koneksi.php' ; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengeluaran Harian</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <h1>Daftar Catatan Pengeluaran Harian<br></h1>
    <a href="create.php">Tambah Catatan</a>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Hari</th>
            <th>Tanggal</th>
            <th>Jumlah</th>
            <th>Action</th>
        </tr>
        <?php
        $result = $conn->query("SELECT * FROM pengeluaran_harian");
        while($row = $result->fetch_assoc()){
            echo "<tr>
            <td>".$row['id']."</td>
            <td>".$row['hari']."</td>
            <td>".$row['tanggal']."</td>
            <td>".$row['jumlah']."</td>
            <td>
            <a href='update.php?id=".$row['id']."'>Edit</a>
            |
            <a href='delete.php?id=".$row['id']."'>Delete</a>
        </td>
        </tr>";
        }
        ?>
</body>
</html>