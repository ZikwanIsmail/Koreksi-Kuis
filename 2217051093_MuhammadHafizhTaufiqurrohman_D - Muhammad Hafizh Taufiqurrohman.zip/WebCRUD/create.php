<?php include 'koneksi.php' ; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catatan Pengeluaran</title>
    <link rel="stylesheet" href="create.css">
</head>
<body>
    <h1>Tambah Catatan<br></h1>
    <form method="post" Action="create.php">
        <label>Hari</label>
        <input type="text" name="hari" required>
        <br>
        <label>Tanggal</label>
        <input type="date" name="tanggal" required>
        <br>
        <label>Jumlah</label>
        <input type="text" name="jumlah" required>
        <br>
        <button type="submit">Tambah Catatan</button>
    </form>

    <a href="index.php">Kembali ke daftar catatan</a>
    <?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
        $hari = $_POST['hari'];
        $tanggal = $_POST['tanggal'];
        $jumlah = $_POST['jumlah'];

        $stmt = $conn->prepare("INSERT INTO pengeluaran_harian (hari, tanggal, jumlah) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $hari, $tanggal, $jumlah);
        if ($stmt->execute()) {
            echo "Catatan baru berhasil ditambahkan.";
        }else{
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    }
    ?>
</body>
</html>