<?php include 'koneksi.php' ; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Catatan</title>
    <link rel="stylesheet" href="update.css">
</head>
<body>
    <h1>Edit Catatan</h1>
    <?php
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $result = $conn->query("SELECT * FROM pengeluaran_harian WHERE id = $id");
        $user = $result->fetch_assoc();
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $id = $_POST['id'];
        $hari = $_POST['hari'];
        $tanggal = $_POST['tanggal'];
        $jumlah = $_POST['jumlah'];

        $stmt = $conn->prepare("UPDATE pengeluaran_harian SET hari = ?, tanggal = ?, jumlah = ? WHERE id = ?");
        $stmt->bind_param("sssi", $hari, $tanggal, $jumlah, $id);
        if ($stmt->execute()) {
            echo "Catatan berhasil di Update.";
        }else {
            echo "Error: ". $stmt->error;
        }
        $stmt->close();
        header("Location: index.php");
        exit;
    }
    ?>
    <form action="update.php" method="post">
        <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
        <label>Hari:</label>
        <input type="text" name="hari" value="<?php echo $user['hari']; ?>" required>
        <br>
        <label>Tanggal</label>
        <input type="date" name="tanggal" value="<?php echo $user['tanggal']; ?>" required>
        <br>
        <label>Jumlah</label>
        <input type="text" name="jumlah" value="<?php echo $user['jumlah']; ?>">
        <br>
        <button type="submit">Update Catatan</button>
    </form>
    <a href="index.php">Kembali ke daftar Catatan</a>
</body>
</html>
