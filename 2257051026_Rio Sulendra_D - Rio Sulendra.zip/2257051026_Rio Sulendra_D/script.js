document.addEventListener("DOMContentLoaded", function () {
    const crudForm = document.getElementById('crudForm');
    const crudTable = document.getElementById('crudTable').getElementsByTagName('tbody')[0];
    const submitButton = crudForm.querySelector('button[type="submit"]');
    const alertOverlay = document.getElementById('alertOverlay');
    const confirmDeleteButton = document.getElementById('confirmDelete');
    const cancelDeleteButton = document.getElementById('cancelDelete');
    let editIndex = null;
    let npmToDelete = null;

    fetchData();

    crudForm.addEventListener('submit', function (e) {
        e.preventDefault();

        const nama = document.getElementById('nama').value;
        const npm = document.getElementById('npm').value;
        const jurusan = document.getElementById('jurusan').value;

        if (editIndex === null) {
            saveData({ npm, nama, jurusan });
        } else {
            updateData({ npm, nama, jurusan });
            editIndex = null;
        }
        resetForm();
    });

    confirmDeleteButton.addEventListener('click', function () {
        deleteData(npmToDelete);
        hideAlert();
    });

    cancelDeleteButton.addEventListener('click', function () {
        hideAlert();
    });

    function fetchData() {
        fetch('crud.php')
            .then(response => response.json())
            .then(data => {
                renderTable(data);
            });
    }

    function saveData(data) {
        fetch('crud.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: new URLSearchParams(data)
        }).then(response => response.text())
          .then(result => {
              console.log(result);
              fetchData();
          });
    }

    function updateData(data) {
        fetch('crud.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: new URLSearchParams(data)
        }).then(response => response.text())
          .then(result => {
              console.log(result);
              fetchData();
          });
    }

    function deleteData(npm) {
        fetch('crud.php', {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: new URLSearchParams({ npm })
        }).then(response => response.text())
          .then(result => {
              console.log(result);
              fetchData();
          });
    }

    function renderTable(dataList) {
        crudTable.innerHTML = '';
        dataList.forEach((data, index) => {
            const row = crudTable.insertRow();
            row.insertCell(0).textContent = index + 1;
            row.insertCell(1).textContent = data.nama;
            row.insertCell(2).textContent = data.npm;
            row.insertCell(3).textContent = data.jurusan;
            const actions = row.insertCell(4);
            actions.appendChild(createButton('edit', index, data));
            actions.appendChild(createButton('hapus', index, data.npm));
        });
    }

    function createButton(action, index, data) {
        const button = document.createElement('button');
        button.className = action;
        button.textContent = action.charAt(0).toUpperCase() + action.slice(1);
        button.addEventListener('click', (e) => {
            e.preventDefault();
            handleAction(action, index, data);
        });
        return button;
    }

    function handleAction(action, index, data) {
        if (action === 'edit') {
            editIndex = index;
            document.getElementById('nama').value = data.nama;
            document.getElementById('npm').value = data.npm;
            document.getElementById('jurusan').value = data.jurusan;
            submitButton.textContent = 'Simpan';
        } else if (action === 'hapus') {
            npmToDelete = data;
            showAlert();
        }
    }

    function resetForm() {
        crudForm.reset();
        submitButton.textContent = 'Tambah';
    }

    function showAlert() {
        alertOverlay.style.visibility = 'visible';
    }

    function hideAlert() {
        alertOverlay.style.visibility = 'hidden';
    }
});
