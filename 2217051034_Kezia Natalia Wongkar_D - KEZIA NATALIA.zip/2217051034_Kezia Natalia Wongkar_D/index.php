<?php
include 'db.php';

// Aktifkan pelaporan kesalahan
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Tangani pengiriman formulir
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['create'])) {
        $title = $conn->real_escape_string($_POST['title']);
        $description = $conn->real_escape_string($_POST['description']);
        $sql = "INSERT INTO tasks (title, description) VALUES ('$title', '$description')";
        if ($conn->query($sql) !== TRUE) {
            echo "Error: " . $sql . "<br>" . $conn->error;
        } else {
            header("Location: myTask.php"); // Redirect ke myTask.php setelah pembuatan berhasil
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>To-Do List</title>
    <link rel="stylesheet" href="style-myTask.css">
</head>
<body>
    <div class="container">
        <h1>To-Do List</h1>
        <a href="myTask.php" class="view-tasks-button">View Tasks</a>
        <form method="POST" action=""> <!-- Mengubah action menjadi kosong agar formulir dikirim ke halaman ini sendiri -->
            <input type="hidden" name="create" value="1">
            <input type="text" name="title" placeholder="Title" required>
            <textarea name="description" placeholder="Description" required></textarea>
            <button type="submit" class="submit-button">Add Task</button>
        </form> 
    </div>
</body>
</html>