<?php
include 'db.php';

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['create'])) {
        $title = $conn->real_escape_string($_POST['title']);
        $description = $conn->real_escape_string($_POST['description']);
        $sql = "INSERT INTO tasks (title, description) VALUES ('$title', '$description')";
        if ($conn->query($sql) !== TRUE) {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    if (isset($_POST['delete'])) {
        $id = $conn->real_escape_string($_POST['id']);
        $sql = "DELETE FROM tasks WHERE id=$id";
        if ($conn->query($sql) !== TRUE) {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    if (isset($_POST['update'])) {
        $id = $conn->real_escape_string($_POST['id']);
        $status = $conn->real_escape_string($_POST['status']) ? 1 : 0;
        $sql = "UPDATE tasks SET status=$status WHERE id=$id";
        if ($conn->query($sql) !== TRUE) {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

// Fetch tasks from the database
$sql = "SELECT * FROM tasks";
$result = $conn->query($sql);
$tasks = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $tasks[] = $row;
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>To-Do List</title>
    <link rel="stylesheet" href="style-myTask.css">
</head>
<body>
    <div class="container">
        <h1>To-Do List</h1>
        <a href="index.php" class="view-tasks-button">Add Task</a>
        <table>
            <thead>
                <tr>
                    <th>Tasks</th>
                    <th>Description</th>
                    <th>Created At</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($tasks as $task) : ?>
                    <tr>
                        <td><?= htmlspecialchars($task['title']) ?></td>
                        <td><?= htmlspecialchars($task['description']) ?></td>
                        <td><?= $task['created_at'] ?></td>
                        <td><?= $task['status'] ? 'Completed' : 'Pending' ?></td>
                        <td>
                            <form method="POST" action="" style="display:inline;">
                                <input type="hidden" name="id" value="<?= $task['id'] ?>">
                                <input type="hidden" name="status" value="<?= $task['status'] ? 0 : 1 ?>">
                                <button type="submit" name="update" class="update-button"><?= $task['status'] ? 'Undo' : 'Complete' ?></button>
                            </form>
                            <form method="POST" action="" style="display:inline;">
                                <input type="hidden" name="id" value="<?= $task['id'] ?>">
                                <button type="submit" name="delete" class="delete-button">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>