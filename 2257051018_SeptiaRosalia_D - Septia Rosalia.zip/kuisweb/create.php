<?php
include 'koneksi.php';

$NPM        = "";
$nama       = "";
$alamat     = "";
$Prodi      = "";
$sukses     = "";
$error      = "";

if (isset($_POST['simpan'])) {
    $NPM        = $_POST['NPM'];
    $nama       = $_POST['nama'];
    $alamat     = $_POST['alamat'];
    $Prodi      = $_POST['Prodi'];

    if ($NPM && $nama && $alamat && $Prodi) {
        $sql1   = "INSERT INTO mahasiswa (NPM, nama, alamat, Prodi) VALUES ('$NPM', '$nama', '$alamat', '$Prodi')";
        $q1     = mysqli_query($koneksi, $sql1);

        if ($q1) {
            header("Location: index.php?sukses=Berhasil memasukkan data baru");
        } else {
            $error = "Gagal memasukkan data: " . mysqli_error($koneksi);
        }
    } else {
        $error = "Silakan masukkan semua data";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Mahasiswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="header-container">
            <h1><b>Welcome Septia Rosalia!</b></h1>
            <h2><b>Universitas Lampung</b></h2>
        </div>
        <nav>
            <ul>
                <li><a href="home.html">Home</a></li>
                <li><a href="index.php">Data Mahasiswa</a></li>
                <li><a href="Jadwal.html">Jadwal Perkuliahan</a></li>
            </ul>
        </nav>
    </header>

    <div class="mx-auto">
        <div class="card">
            <div class="card-header">
                Create Data
            </div>
            <div class="card-body">
                <?php
                if ($error) {
                    echo "<div class='alert alert-danger' role='alert'>$error</div>";
                }
                ?>
                <form action="" method="POST">
                    <div class="mb-3 row">
                        <label for="NPM" class="col-sm-2 col-form-label">NPM</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="NPM" name="NPM" value="<?php echo $NPM ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="nama" class="col-sm-2 col-form-label">Nama</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="nama" name="nama" value="<?php echo $nama ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="alamat" class="col-sm-2 col-form-label">Alamat</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="alamat" name="alamat" value="<?php echo $alamat ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="Prodi" class="col-sm-2 col-form-label">Prodi</label>
                        <div class="col-sm-10">
                            <select class="form-control" name="Prodi" id="Prodi">
                                <option value="">- Pilih Prodi -</option>
                                <option value="S1 Ilmu Komputer" <?php if ($Prodi == "S1 Ilmu Komputer") echo "selected" ?>>S1 Ilmu Komputer</option>
                                <option value="D3 Manajemen Informatika" <?php if ($Prodi == "D3 Manajemen Informatika") echo "selected" ?>>D3 Manajemen Informatika</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-buttons">
                        <a href="index.php" class="btn btn-secondary">Kembali</a>
                        <input type="submit" name="simpan" value="Simpan Data" class="btn btn-primary" />
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
