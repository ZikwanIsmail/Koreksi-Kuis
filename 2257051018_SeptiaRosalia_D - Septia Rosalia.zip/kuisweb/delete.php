<?php
include 'koneksi.php';

$id         = $_GET['id'];
$sql1       = "delete from mahasiswa where id = '$id'";
$q1         = mysqli_query($koneksi, $sql1);

if ($q1) {
    header("Location: index.php?sukses=Berhasil hapus data");
} else {
    header("Location: index.php?error=Gagal melakukan delete data");
}
?>
