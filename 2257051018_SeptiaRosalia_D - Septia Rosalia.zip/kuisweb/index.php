<?php
include 'koneksi.php';

$sukses     = "";
$error      = "";

if (isset($_GET['sukses'])) {
    $sukses = $_GET['sukses'];
}

if (isset($_GET['error'])) {
    $error = $_GET['error'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Mahasiswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="header-container">
            <h1><b>Welcome Septia Rosalia!</b></h1>
            <h2><b>Universitas Lampung</b></h2>
        </div>
        <nav>
            <ul>
                <li><a href="home.html">Home</a></li>
                <li><a href="index.php">Data Mahasiswa</a></li>
                <li><a href="Jadwal.html">Jadwal Perkuliahan</a></li>
            </ul>
        </nav>
    </header>
 <div class="mx-auto">
        <?php
        if ($error) {
            echo "<div class='alert alert-danger' role='alert'>$error</div>";
        }
        if ($sukses) {
            echo "<div class='alert alert-success' role='alert'>$sukses</div>";
        }
        ?>
        <div class="card">
            <div class="card-header">
                Data Mahasiswa
            </div>
            <div class="card-body">
                <a href="create.php" class="btn btn-success">Tambah Data</a>
                <table class="table mt-3">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>NPM</th>
                            <th>Nama</th>
                            <th>Alamat</th>
                            <th>Prodi</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sql2   = "select * from mahasiswa order by id desc";
                        $q2     = mysqli_query($koneksi, $sql2);
                        $urut   = 1;
                        while ($r2 = mysqli_fetch_array($q2)) {
                            $id     = $r2['id'];
                            $NPM    = $r2['NPM'];
                            $nama   = $r2['nama'];
                            $alamat = $r2['alamat'];
                            $Prodi  = $r2['Prodi'];
                            
                            // Check if it's the header row
                            $headerRowClass = '';
                            if ($urut <= 4) {
                                $headerRowClass = 'header-row';
                            }
                            
                            echo "<tr class='$headerRowClass'>
                                    <th scope='row'>$urut</th>
                                    <td>$NPM</td>
                                    <td>$nama</td>
                                    <td>$alamat</td>
                                    <td>$Prodi</td>
                                    <td>
                                        <a href='update.php?id=$id' class='btn btn-warning'>Edit</a>
                                        <a href='delete.php?id=$id' class='btn btn-danger' onclick='return confirm(\"Yakin mau delete data?\")'>Delete</a>
                                    </td>
                                  </tr>";
                            $urut++;
                        }
                        
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
