<?php
include 'koneksi.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method == 'POST') {
    $nama = $_POST['nama'];
    $npm = $_POST['npm'];
    $jurusan = $_POST['jurusan'];

    $sql = "REPLACE INTO mahasiswa (npm, nama, jurusan) VALUES ('$npm', '$nama', '$jurusan')";

    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

} else if ($method == 'DELETE') {
    parse_str(file_get_contents("php://input"), $post_vars);
    if (isset($post_vars['npm'])) {
        $npm = $post_vars['npm'];

        $sql = "DELETE FROM mahasiswa WHERE npm='$npm'";

        if ($conn->query($sql) === TRUE) {
            echo "Record deleted successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Error: npm not provided";
    }

} else if ($method == 'GET') {
    $sql = "SELECT * FROM mahasiswa";
    $result = $conn->query($sql);

    $data = array();
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    echo json_encode($data);
}

$conn->close();
?>
