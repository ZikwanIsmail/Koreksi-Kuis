<?php include 'config.php'; ?>
<?php include 'header.php'; ?>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];

    $sql = "INSERT INTO items (name, quantity, price) VALUES ('$name', $quantity, $price)";

    if ($conn->query($sql) === TRUE) {
        header("Location: home.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>
<link rel="stylesheet" href="styles.css">
<h1 class="mb-4">Tambah Barang</h1>
<form method="post" action="Tambah_barang.php">
    <div class="form-group">
        <label for="name">Nama Barang</label>
        <input type="text" class="form-control" id="name" name="name" required>
    </div>
    <div class="form-group">
        <label for="quantity">Jumlah</label>
        <input type="number" class="form-control" id="quantity" name="quantity" required>
    </div>
    <div class="form-group">
        <label for="price">Harga</label>
        <input type="number" step="0.01" class="form-control" id="price" name="price" required>
    </div>
    <button type="submit" class="btn btn-custom" ><i class="fas fa-plus-circle"></i> Tambah</button>
</form>

<?php include 'footer.php'; ?>
