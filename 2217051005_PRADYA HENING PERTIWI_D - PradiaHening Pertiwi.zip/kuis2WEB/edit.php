<?php include 'config.php'; ?>
<?php include 'header.php'; ?>

<?php
$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];

    $sql = "UPDATE items SET name='$name', quantity=$quantity, price=$price WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        header("Location: home.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    $sql = "SELECT * FROM items WHERE id=$id";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
}
?>

<h1 class="mb-4">Edit Barang</h1>
<form method="post" action="edit.php?id=<?php echo $id; ?>">
    <div class="form-group">
        <label for="name">Nama Barang</label>
        <input type="text" class="form-control" id="name" name="name" value="<?php echo $row['name']; ?>" required>
    </div>
    <div class="form-group">
        <label for="quantity">Jumlah</label>
        <input type="number" class="form-control" id="quantity" name="quantity" value="<?php echo $row['quantity']; ?>" required>
    </div>
    <div class="form-group">
        <label for="price">Harga</label>
        <input type="number" step="0.01" class="form-control" id="price" name="price" value="<?php echo $row['price']; ?>" required>
    </div>
    <button type="submit" class="btn btn-custom"><i class="fas fa-save"></i> Update</button>
</form>

<?php include 'footer.php'; ?>
