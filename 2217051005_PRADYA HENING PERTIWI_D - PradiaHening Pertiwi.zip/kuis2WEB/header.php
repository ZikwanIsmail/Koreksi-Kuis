<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toko Sembako</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
        <nav class="navbar navbar-expand-md navbar-light" style="background-color: #FF90BC;">
        <a class="navbar-brand" href="home.php"><i class="fas fa-store"></i> Toko Sembako</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="tambah_barang.php"><i class="fas fa-plus-circle"></i> Tambah Barang</a>
                </li>
            </ul>
        </div>
    </nav>
<div class="container mt-4">
