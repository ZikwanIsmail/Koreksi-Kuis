</div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <div class="footer mt-4">
        <p>
            &copy; 2024 Toko Sembako &nbsp; 
            <i class="fas fa-carrot"></i> &nbsp;
            <i class="fas fa-apple-alt"></i> &nbsp;
            <i class="fas fa-lemon"></i> &nbsp;
            <i class="fas fa-pepper-hot"></i> &nbsp;
            <i class="fas fa-cheese"></i> &nbsp;
            <i class="fas fa-bread-slice"></i>
        </p>
    </div>

</body>
</html>
