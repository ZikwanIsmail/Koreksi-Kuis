<?php include 'config.php'; ?>

<?php
$id = $_GET['id'];

$sql = "DELETE FROM items WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    header("Location: home.php");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
?>
