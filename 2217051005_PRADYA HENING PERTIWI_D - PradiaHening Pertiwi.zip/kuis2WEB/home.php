<?php include 'config.php'; ?>
<?php include 'header.php'; ?>

<h1 class="mb-4">Daftar Barang</h1>
<table class="table table-hover">
    <thead>
        <tr>
            <th>Nama Barang</th>
            <th>Jumlah</th>
            <th>Harga</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $sql = "SELECT * FROM items";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['name']}</td>
                        <td>{$row['quantity']}</td>
                        <td>Rp{$row['price']}</td>
                        <td>
                            <a href='edit.php?id={$row['id']}' class='btn btn-custom btn-sm'><i class='fas fa-edit'></i> Edit</a>
                            <a href='hapus.php?id={$row['id']}' class='btn btn-custom btn-sm'><i class='fas fa-trash'></i> Hapus</a>
                        </td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='4'>Tidak ada data</td></tr>";
        }
        ?>
    </tbody>
</table>

<div class="footer">
    &copy; 2024 Toko Sembako
</div>

<?php include 'footer.php'; ?>
