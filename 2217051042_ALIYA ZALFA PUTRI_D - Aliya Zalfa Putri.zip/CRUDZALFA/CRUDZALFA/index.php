<?php include 'config.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>KUIS 2 ALIYA ZALFA</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Contact List Handphone Aliya 📞</h1>
        </header>
        <a href="create.php">Add New Contact</a>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th class="id">ID</th>
                        <th class="name">Name</th>
                        <th class="email">Email</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th>City</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $result = $conn->query("SELECT c.id, c.name, c.email, c.phone, a.address, a.city FROM contacts c JOIN addresses a ON c.id = a.contact_id");
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td class='id'>" . $row['id'] . "</td>";
                        echo "<td class='name'>" . $row['name'] . "</td>";
                        echo "<td class='email'>" . $row['email'] . "</td>";
                        echo "<td>" . $row['phone'] . "</td>";
                        echo "<td>" . $row['address'] . "</td>";
                        echo "<td>" . $row['city'] . "</td>";
                        echo "<td>";
                        echo "<a href='update.php?id=" . $row['id'] . "'>Edit</a> | ";
                        echo "<a href='delete.php?id=" . $row['id'] . "'>Delete</a>";
                        echo "</td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
