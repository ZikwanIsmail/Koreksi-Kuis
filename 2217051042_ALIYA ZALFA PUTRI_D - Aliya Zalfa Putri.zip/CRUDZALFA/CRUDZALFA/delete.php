<?php
include "config.php";

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Begin transaction
    $conn->begin_transaction();

    try {
        // Delete from addresses
        $stmt = $conn->prepare("DELETE FROM addresses WHERE contact_id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();

        // Delete from contacts
        $stmt = $conn->prepare("DELETE FROM contacts WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();

        // Commit transaction
        $conn->commit();

        $message = "Contact deleted successfully.";
    } catch (Exception $e) {
        // Rollback transaction
        $conn->rollback();
        $message = "Error: " . $e->getMessage();
    }

    // Close the statement
    $stmt->close();

    // Close the connection
    $conn->close();
} else {
    $message = "No contact ID provided.";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Delete Contact</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Delete Contact</h1>
        </header>
        <p><?php echo $message; ?></p>
        <a href="index.php">Back to Contact List</a>
    </div>
</body>
</html>
