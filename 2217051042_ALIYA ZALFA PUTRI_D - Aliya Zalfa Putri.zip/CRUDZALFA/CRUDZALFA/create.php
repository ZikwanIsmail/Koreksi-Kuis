<?php include 'config.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Contact</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Add New Contact</h1>
        </header>
        <form method="post" action="create.php">
            <label>Name:</label>
            <input type="text" name="name" required>
            <label>Email:</label>
            <input type="email" name="email" required>
            <label>Phone:</label>
            <input type="text" name="phone" required>
            <label>Address:</label>
            <input type="text" name="address" required>
            <label>City:</label>
            <input type="text" name="city" required>
            <button type="submit">Add Contact</button>
        </form>
        <a href="index.php">Back to Contact List</a>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $name = $_POST['name'];
            $email = $_POST['email'];
            $phone = $_POST['phone'];
            $address = $_POST['address'];
            $city = $_POST['city'];

            // Begin transaction
            $conn->begin_transaction();

            try {
                // Insert into contacts
                $stmt = $conn->prepare("INSERT INTO contacts (name, email, phone) VALUES (?, ?, ?)");
                $stmt->bind_param("sss", $name, $email, $phone);
                $stmt->execute();

                $contact_id = $stmt->insert_id;

                // Insert into addresses
                $stmt = $conn->prepare("INSERT INTO addresses (contact_id, address, city) VALUES (?, ?, ?)");
                $stmt->bind_param("iss", $contact_id, $address, $city);
                $stmt->execute();

                // Commit transaction
                $conn->commit();

                echo "New contact added successfully.";
            } catch (Exception $e) {
                // Rollback transaction
                $conn->rollback();
                echo "Error: " . $e->getMessage();
            }

            // Close the statement
            $stmt->close();

            // Close the connection
            $conn->close();
        }
        ?>
    </div>
</body>
</html>
