<?php include "config.php"; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Contact</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Edit Contact</h1>
        </header>
        <?php
        if (isset($_GET['id'])) {
            $id = $_GET['id'];
            $result = $conn->query("SELECT c.id, c.name, c.email, c.phone, a.address, a.city FROM contacts c JOIN addresses a ON c.id = a.contact_id WHERE c.id = $id");
            if ($result && $result->num_rows > 0) {
                $contact = $result->fetch_assoc();
            } else {
                echo "Contact not found.";
                exit;
            }
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $id =
            $_POST['id'];
            $name = $_POST['name'];
            $email = $_POST['email'];
            $phone = $_POST['phone'];
            $address = $_POST['address'];
            $city = $_POST['city'];

            // Begin transaction
            $conn->begin_transaction();

            try {
                // Update contacts
                $stmt = $conn->prepare("UPDATE contacts SET name = ?, email = ?, phone = ? WHERE id = ?");
                $stmt->bind_param("sssi", $name, $email, $phone, $id);
                $stmt->execute();

                // Update addresses
                $stmt = $conn->prepare("UPDATE addresses SET address = ?, city = ? WHERE contact_id = ?");
                $stmt->bind_param("ssi", $address, $city, $id);
                $stmt->execute();

                // Commit transaction
                $conn->commit();

                echo "Contact updated successfully.";
            } catch (Exception $e) {
                // Rollback transaction
                $conn->rollback();
                echo "Error: " . $e->getMessage();
            }

            // Close the statement
            $stmt->close();

            // Close the connection
            $conn->close();

            header("Location: index.php");
            exit;
        }
        ?>

        <form method="post" action="update.php">
            <input type="hidden" name="id" value="<?php echo $contact['id']; ?>">
            <label>Name:</label>
            <input type="text" name="name" value="<?php echo $contact['name']; ?>" required>
            <label>Email:</label>
            <input type="email" name="email" value="<?php echo $contact['email']; ?>" required>
            <label>Phone:</label>
            <input type="text" name="phone" value="<?php echo $contact['phone']; ?>" required>
            <label>Address:</label>
            <input type="text" name="address" value="<?php echo $contact['address']; ?>" required>
            <label>City:</label>
            <input type="text" name="city" value="<?php echo $contact['city']; ?>" required>
            <button type="submit">Update Contact</button>
        </form>
        <a href="index.php">Back to Contact List</a>
    </div>
</body>
</html>
