<?php

$host = "localhost";
$user = "root";
$pass = "";
$db = "db_kuliah";

$connection = new mysqli($host, $user, $pass, $db);

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$npm = "";
$nama = "";
$program_studi = "";
$jenis_kelamin = "";

$errorMessage = "";
$successMessage = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $npm = $_POST["npm"];
    $nama = $_POST["nama"];
    $program_studi = $_POST["prodi"];
    $jenis_kelamin = $_POST["jk"];

    do {
        if (empty($npm) || empty($nama) || empty($program_studi) || empty($jenis_kelamin)) {
            $errorMessage = "Semua bidang wajib diisi";
            break;
        }

        // Add new mahasiswa to database
        $sql = "INSERT INTO mahasiswa_ilkom_d (npm, nama, program_studi, jenis_kelamin) VALUES ('$npm', '$nama', '$program_studi', '$jenis_kelamin')";
        
        try {
            $result = $connection->query($sql);

            if (!$result) {
                throw new Exception($connection->error);
            }

            $npm = "";
            $nama = "";
            $program_studi = "";
            $jenis_kelamin = "";

            $successMessage = "Data Mahasiswa Berhasil Ditambahkan";

            header("Location: index.php");
            exit;

        } catch (mysqli_sql_exception $e) {
            if ($connection->errno == 1062) { // Duplicate entry error code
                $errorMessage = "NPM sudah ada, masukkan NPM yang berbeda.";
            } else {
                $errorMessage = "Invalid query: " . $connection->error;
            }
        }

    } while (false);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <!-- Bootstrap-->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"></script>

    <!--font awesome-->
    <link rel="stylesheet" href="fontawesome/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TAMBAH DATA</title>
</head>
<body>
    <nav class="navbar navbar-light bg-light mb-4">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">
          ‧₊˚ ☁️⋅♡ CRUD - Create Read Update Delete
          </a>
        </div>
    </nav> 
    <div class="container">
    <h1 class="mt-4">
    <center>
    Tambah Data Mahasiswa</h1><br>
    </center>

    <?php
    if (!empty($errorMessage)) {
        echo "
        <div class='alert alert-warning alert-dismissible fade show' role='alert'>
            <strong>$errorMessage</strong>
            <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
        </div>
        ";
    }
    ?>

    <form method="post">
        <div class="mb-3 row">
            <label for="npm" class="col-sm-2 col-form-label">NPM</label>
            <div class="col-sm-10">
               <input type="text" class="form-control" id="npm" name="npm" placeholder="NPM" value="<?php echo htmlspecialchars($npm); ?>">
            </div>
        </div>
        <div class="mb-3 row">
            <label for="nama" class="col-sm-2 col-form-label">Nama</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="nama" name="nama" placeholder="Nama" value="<?php echo htmlspecialchars($nama); ?>">
            </div>
        </div>
        <div class="mb-3 row">
            <label for="jk" class="col-sm-2 col-form-label">Jenis Kelamin</label>
            <div class="col-sm-10">
                <select id="jk" name="jk" class="form-select">
                  <option value="Laki-laki" <?php echo $jenis_kelamin == 'Laki-laki' ? 'selected' : ''; ?>>Laki-laki</option>
                  <option value="Perempuan" <?php echo $jenis_kelamin == 'Perempuan' ? 'selected' : ''; ?>>Perempuan</option>
                </select>
            </div>
        </div>
        <div class="mb-3 row">
            <label for="prodi" class="col-sm-2 col-form-label">Program Studi</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="prodi" name="prodi" placeholder="Program Studi" value="<?php echo htmlspecialchars($program_studi); ?>">
            </div>
        </div>

        <?php
         if (!empty($successMessage)) {
            echo "
            <div class='row mb-3'>
                <div class='offset-sm-3 col-sm-6'>
                    <div class='alert alert-success alert-dismissible fade show' role='alert'>
                        <strong>$successMessage</strong>
                        <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                    </div>
                </div>
            </div>
            ";
         }
        ?>

        <div class="mb-3 row mt-4">
            <div class="col">
                <button type="submit" name="aksi" value="add" class="btn btn-primary">
                    <i class="fa fa-floppy-o" aria-hidden="true"></i>
                    Tambah
                </button>
                <a href="index.php" type="button" class="btn btn-danger">
                    <i class="fa fa-times" aria-hidden="true"></i>
                    Batal
                </a>
            </div>
        </div>
      </div>
    </form>
</body>
</html>
