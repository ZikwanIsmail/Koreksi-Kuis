<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Bundle JS -->
    <script src="js/bootstrap.bundle.min.js"></script>

    <!-- Font Awesome -->
    <link rel="stylesheet" href="fontawesome/css/font-awesome.min.css">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DATA MAHASISWA ILKOM D</title>
</head>
<body>
    <nav class="navbar navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#"> ‧₊˚ ☁️⋅♡ CRUD - Create Read Update Delete</a>
        </div>
    </nav>

    <div class="container">
        <h1 class="mt-4">Data Mahasiswa Ilkom D</h1>
        <figure>
            <blockquote class="blockquote">
                <p>Berisi data yang telah tersimpan di database</p>
            </blockquote>
            <figcaption class="blockquote-footer">
                CRUD <cite title="Source Title">Create Read Update Delete</cite>
            </figcaption>
        </figure>
        <a href="create.php" class="btn btn-primary mb-3">
            <i class="fa fa-plus"></i>
            Tambah data
        </a>

        <?php
        // Check for success message in the URL parameter
        $successMessage = isset($_GET['successMessage']) ? $_GET['successMessage'] : '';

        if (!empty($successMessage)) {
            echo "
            <div id='successMessage' class='alert alert-success alert-dismissible fade show'>
                <strong>$successMessage</strong>
                <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
            </div>
            ";
        }
        ?>

        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th style="background-color: #FFEA00;" scope="col">NPM</th>
                        <th style="background-color: #FFEA00;" scope="col">Nama</th>
                        <th style="background-color: #FFEA00;" scope="col">Program Studi</th>
                        <th style="background-color: #FFEA00;" scope="col">Jenis Kelamin</th>
                        <th style="background-color: #FFEA00;" scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $host = "localhost";
                $user = "root";
                $pass = "";
                $db = "db_kuliah";

                // Create connection
                $connection = new mysqli($host, $user, $pass, $db);

                // Check connection
                if ($connection->connect_error) {
                    die("Connection failed: " . $connection->connect_error);
                }

                // Read all rows from database table
                $sql = "SELECT * FROM mahasiswa_ilkom_d";
                $result = $connection->query($sql);

                if ($result->num_rows > 0) {
                    // Output data of each row
                    while($row = $result->fetch_assoc()) {
                        echo "
                        <tr>
                            <td>{$row['npm']}</td>
                            <td>{$row['nama']}</td>
                            <td>{$row['program_studi']}</td>
                            <td>{$row['jenis_kelamin']}</td>
                            <td>
                                <a href='update.php?npm={$row['npm']}' class='btn btn-success btn-sm'>
                                    <i class='fa fa-pencil'></i>
                                    Edit
                                </a>
                                <a href='delete.php?npm={$row['npm']}' class='btn btn-danger btn-sm' onclick=\"return confirm('Apakah Anda yakin ingin menghapus data tersebut?');\">
                                    <i class='fa fa-trash'></i>
                                    Hapus
                                </a>
                            </td>
                        </tr>
                        ";
                    }
                } else {
                    echo "<tr><td colspan='5'>
                    <center>Tidak ada data <center> </td></tr>";
                }

                // Close connection
                $connection->close();
                ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        // JavaScript to hide success message after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            var successMessage = document.getElementById('successMessage');
            if (successMessage) {
                setTimeout(function() {
                    successMessage.style.display = 'none';
                }, 5000);
            }
        });
    </script>
</body>
</html>
