-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 26 Bulan Mei 2024 pada 05.09
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_kuliah`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `mahasiswa_ilkom_d`
--

CREATE TABLE `mahasiswa_ilkom_d` (
  `npm` varchar(50) NOT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `program_studi` varchar(100) DEFAULT NULL,
  `jenis_kelamin` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `mahasiswa_ilkom_d`
--

INSERT INTO `mahasiswa_ilkom_d` (`npm`, `nama`, `program_studi`, `jenis_kelamin`) VALUES
('2217051087', 'Jhon V Nababan', 'S1 - Ilmu Komputer', 'Laki-laki'),
('2217051149', 'Zainab Aqilah', 'S1 - Ilmu Komputer', 'Perempuan'),
('2217051154', 'Rio Arisandi', 'S1 - Ilmu Komputer', 'Laki-laki'),
('2257051013', 'Wayan Santie Arif', 'S1 - Ilmu Komputer', 'Laki-laki');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `mahasiswa_ilkom_d`
--
ALTER TABLE `mahasiswa_ilkom_d`
  ADD PRIMARY KEY (`npm`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
