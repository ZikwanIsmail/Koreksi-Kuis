<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "db_kuliah";

$connection = new mysqli($host, $user, $pass, $db);

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$npm = "";
$nama = "";
$program_studi = "";
$jenis_kelamin = "";

$errorMessage = "";
$successMessage = "";

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // GET method: Show the data of the client

    if (!isset($_GET["npm"])) {
        header("location: index.php");
        exit;
    }
    
    $npm = $_GET["npm"];

    // Fetch the selected client's row from the database table
    $sql = "SELECT * FROM mahasiswa_ilkom_d WHERE npm='$npm'";
    $result = $connection->query($sql);

    if (!$result) {
        $errorMessage = "Invalid query: " . $connection->error;
    } else {
        $row = $result->fetch_assoc();
        if (!$row) {
            header("location: index.php");
            exit;
        }

        $nama = $row["nama"];
        $program_studi = $row["program_studi"];
        $jenis_kelamin = $row["jenis_kelamin"];
    }
} else {
    // POST method: Update data mahasiswa
    $npm = $_POST["npm"];
    $nama = $_POST["nama"];
    $program_studi = $_POST["prodi"];
    $jenis_kelamin = $_POST["jk"];

    do {
        if (empty($npm) || empty($nama) || empty($program_studi) || empty($jenis_kelamin)) {
            $errorMessage = "Semua bidang wajib diisi";
            break;
        }

        $sql = "UPDATE mahasiswa_ilkom_d SET nama='$nama', program_studi='$program_studi', jenis_kelamin='$jenis_kelamin' WHERE npm='$npm'";

        $result = $connection->query($sql);

        if (!$result) {
            $errorMessage = "Invalid query: " . $connection->error;
            break;
        }

        $successMessage = "Data Mahasiswa Berhasil di Update!";

        // Redirect back to index.php with success message
        header("location: index.php?successMessage=" . urlencode($successMessage));
        exit;

        break;
    } while (true);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data Mahasiswa</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="fontawesome/css/font-awesome.min.css">
</head>
<body>
    <nav class="navbar navbar-light bg-light mb-4">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">‧₊˚ ☁️⋅♡ CRUD - Create Read Update Delete</a>
        </div>
    </nav>

    <div class="container">
        <h1 class="mt-4 text-center">Edit Data Mahasiswa</h1>

        <?php
        if (!empty($errorMessage)) {
            echo "
            <div class='alert alert-warning alert-dismissible fade show' role='alert'>
                <strong>$errorMessage</strong>
                <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
            </div>
            ";
        }
        ?>

        <form id="editForm" method="post">
            <input type="hidden" name="npm" value="<?php echo htmlspecialchars($npm); ?>">
            <div class="mb-3 row">
                <label for="npm" class="col-sm-2 col-form-label">NPM</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="npm" name="npm" placeholder="NPM" value="<?php echo htmlspecialchars($npm); ?>" readonly>
                </div>
            </div>
            <div class="mb-3 row">
                <label for="nama" class="col-sm-2 col-form-label">Nama</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="nama" name="nama" placeholder="Nama" value="<?php echo htmlspecialchars($nama); ?>">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="jk" class="col-sm-2 col-form-label">Jenis Kelamin</label>
                <div class="col-sm-10">
                    <select id="jk" name="jk" class="form-select">
                        <option value="Laki-laki" <?php echo $jenis_kelamin == 'Laki-laki' ? 'selected' : ''; ?>>Laki-laki</option>
                        <option value="Perempuan" <?php echo $jenis_kelamin == 'Perempuan' ? 'selected' : ''; ?>>Perempuan</option>
                    </select>
                </div>
            </div>
            <div class="mb-3 row">
                <label for="prodi" class="col-sm-2 col-form-label">Program Studi</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="prodi" name="prodi" placeholder="Program Studi" value="<?php echo htmlspecialchars($program_studi); ?>">
                </div>
            </div>

            <div class="mb-3 row mt-4">
                <div class="col">
                    <button type="submit" name="aksi" value="update" class="btn btn-primary">
                        <i class="fa fa-floppy-o" aria-hidden="true"></i>
                        Update
                    </button>
                    <a href="index.php" type="button" class="btn btn-danger">
                        <i class="fa fa-times" aria-hidden="true"></i>
                        Batal
                    </a>
                </div>
            </div>
        </form>
    </div>

    <script>
        // JavaScript to hide success message after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            var successMessage = document.getElementById('successMessage');
            if (successMessage) {
                setTimeout(function() {
                    successMessage.style.display = 'none';
                }, 5000);
            }
        });
    </script>
</body>
</html>
