<?php
include 'db_config.php';

$id = $_GET['id'];

// Query untuk menghapus data hewan peliharaan dengan prepared statement
$stmt = $conn->prepare("DELETE FROM pets WHERE id=?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    $stmt->close();
    echo "<script>alert('Data hewan peliharaan berhasil dihapus'); window.location.href='index.php';</script>";
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>
