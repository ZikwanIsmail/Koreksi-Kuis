<?php
include 'db_config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $type = $_POST['type'];
    $birthdate = $_POST['birthdate'];
    $owner_name = $_POST['owner_name'];

    // Query untuk menambahkan data hewan peliharaan dengan prepared statement
    $stmt = $conn->prepare("INSERT INTO pets (name, type, birthdate, owner_name) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $type, $birthdate, $owner_name);

    if ($stmt->execute()) {
        $stmt->close();
        echo "<script>alert('Data hewan peliharaan berhasil ditambahkan'); window.location.href='index.php';</script>";
    } else {
        echo "Error: " . $stmt->error;
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Hewan Peliharaan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 30px;
        }
        form {
            margin-top: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
        }
        input[type="text"], input[type="date"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Tambah Hewan Peliharaan</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <label for="name">Nama:</label>
            <input type="text" id="name" name="name" required>
            <label for="type">Jenis:</label>
            <input type="text" id="type" name="type" required>
            <label for="birthdate">Tanggal Lahir:</label>
            <input type="date" id="birthdate" name="birthdate" required>
            <label for="owner_name">Nama Pemilik:</label>
            <input type="text" id="owner_name" name="owner_name" required>
            <input type="submit" value="Tambahkan">
        </form>
    </div>
</body>
</html>
