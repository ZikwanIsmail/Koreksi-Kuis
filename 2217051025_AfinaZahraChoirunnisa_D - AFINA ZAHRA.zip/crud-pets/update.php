<?php
include 'db_config.php';

$id = $_POST['id'];
$name = $_POST['name'];
$type = $_POST['type'];
$birthdate = $_POST['birthdate'];
$owner_name = $_POST['owner_name'];

// Query untuk memperbarui data hewan peliharaan dengan prepared statement
$stmt = $conn->prepare("UPDATE pets SET name=?, type=?, birthdate=?, owner_name=? WHERE id=?");
$stmt->bind_param("ssssi", $name, $type, $birthdate, $owner_name, $id);

if ($stmt->execute()) {
    $stmt->close();
    echo "<script>alert('Data hewan peliharaan berhasil diperbarui'); window.location.href='index.php';</script>";
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();
?>
